import { defineAuth } from '@aws-amplify/backend';

export const auth = defineAuth({
  loginWith: {
    email: true,
  },  
  groups: ["ADMINS", "EVERYONE", "PREMIUM"],
  userAttributes: {
    nickname: {
      mutable: true,
      required: false,
    },
  }
});